/**
 * Направление вращения тетримино.
 */
export enum RotationDirection {
  Clockwise = 'clockwise',
  CounterClockwise = 'counter_clockwise',
}
