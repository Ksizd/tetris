/**
 * Содержимое ячейки цилиндрического поля.
 */
export enum CellContent {
  Empty = 'empty',
  Block = 'block',
}
