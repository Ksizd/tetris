export const LOCK_DELAY_MAX_MS = 600;
export const LOCK_MOVES_MAX = 15;
