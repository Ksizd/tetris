import { describe, expect, it } from 'vitest';

describe('smoke test', () => {
  it('adds numbers correctly', () => {
    expect(2 + 2).toBe(4);
  });
});
