import * as THREE from 'three';
import { BoardDimensions } from '../core/types';
import { BoardRenderConfig } from './boardConfig';
import { PlatformLayout } from './platformLayout';
import { getFootprintRadius } from './towerFootprint';

export interface FootprintDecorParams {
  dimensions: BoardDimensions;
  board: BoardRenderConfig;
  platformLayout: PlatformLayout;
}

const EPS = 1e-4;

export function createFootprintDecor(params: FootprintDecorParams): THREE.Group {
  const { dimensions, board, platformLayout } = params;
  const group = new THREE.Group();
  group.name = 'footprintDecor';

  const footprintRadius = getFootprintRadius(board);
  const floorY = -board.blockSize * 0.5;
  const yBase = floorY + board.blockSize * 0.02; // higher above cube floor for visibility

  // Layer 1: thin ring engraving
  const ringWidth = board.blockSize * 0.5;
  const ringInner = Math.max(0, footprintRadius - ringWidth * 0.5);
  const ringOuter = Math.min(
    footprintRadius + ringWidth * 0.5,
    Math.min(platformLayout.ringB.outer, platformLayout.ringC.inner) - EPS
  );
  const ringSegments = Math.max(24, dimensions.width * 2);
  const ringGeometry = new THREE.RingGeometry(ringInner, ringOuter, ringSegments, 1);
  const ringMaterial = new THREE.MeshStandardMaterial({
    color: 0x9c7a3a,
    metalness: 0.46,
    roughness: 0.52,
    emissive: 0x0d0a06,
    emissiveIntensity: 0.08,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: 1,
    polygonOffsetUnits: 1,
  });
  const ringMesh = new THREE.Mesh(ringGeometry, ringMaterial);
  ringMesh.rotation.x = -Math.PI / 2;
  ringMesh.position.y = yBase;
  ringMesh.name = 'footprintRingEngraving';
  ringMesh.renderOrder = -2;
  group.add(ringMesh);

  // Layer 2: cell sectors
  const sectorInner = Math.max(0, footprintRadius - board.blockSize * 0.5);
  const sectorOuter = Math.min(
    footprintRadius + board.blockSize * 0.5,
    Math.min(platformLayout.ringB.outer, platformLayout.ringC.inner) - EPS
  );
  const sectorGeometry = buildCellSectorGeometry(dimensions.width, sectorInner, sectorOuter);
  const sectorMaterial = new THREE.MeshStandardMaterial({
    color: 0xf3d8a2,
    metalness: 0.52,
    roughness: 0.42,
    emissive: 0xf6d8a2,
    emissiveIntensity: 0.24,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: 1.5,
    polygonOffsetUnits: 1.5,
  });
  const sectorMesh = new THREE.Mesh(sectorGeometry, sectorMaterial);
  sectorMesh.rotation.x = 0; // geometry already in XZ plane; keep flat on platform
  sectorMesh.position.y = yBase + 0.002;
  sectorMesh.name = 'footprintCellSectors';
  sectorMesh.renderOrder = -1;
  group.add(sectorMesh);

  return group;
}

function buildCellSectorGeometry(
  columnCount: number,
  innerRadius: number,
  outerRadius: number
): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const step = (Math.PI * 2) / columnCount;

  const pushVertex = (x: number, y: number, z: number, u: number, v: number) => {
    positions.push(x, y, z);
    normals.push(0, 1, 0);
    uvs.push(u, v);
    return positions.length / 3 - 1;
  };

  for (let col = 0; col < columnCount; col += 1) {
    const t0 = (col - 0.5) * step;
    const t1 = (col + 0.5) * step;
    const c0 = Math.cos(t0);
    const s0 = Math.sin(t0);
    const c1 = Math.cos(t1);
    const s1 = Math.sin(t1);

    const v0 = pushVertex(innerRadius * c0, 0, innerRadius * s0, col / columnCount, 0);
    const v1 = pushVertex(outerRadius * c0, 0, outerRadius * s0, col / columnCount, 1);
    const v2 = pushVertex(innerRadius * c1, 0, innerRadius * s1, (col + 1) / columnCount, 0);
    const v3 = pushVertex(outerRadius * c1, 0, outerRadius * s1, (col + 1) / columnCount, 1);

    indices.push(v0, v1, v2, v2, v1, v3);
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeBoundingBox();
  geometry.computeBoundingSphere();
  return geometry;
}
