import { BoardRenderConfig } from './boardConfig';
import { HallLayoutRadii } from './hallLayout';
import { PlatformDesignSpec, createDefaultPlatformDesign } from './platformDesign';
import { getFootprintRadius } from './towerFootprint';

export interface PlatformRingLayout {
  inner: number;
  outer: number;
  height: number;
}

export interface PlatformLayout {
  baseY: number; // y-низ платформы
  heightCore: number; // высота основного кольца (ringC baseline)
  ringA: PlatformRingLayout;
  ringB: PlatformRingLayout;
  ringC: PlatformRingLayout;
}

const EPS = 1e-4;

export function computePlatformLayout(
  hallLayout: HallLayoutRadii,
  board: BoardRenderConfig,
  design: PlatformDesignSpec = createDefaultPlatformDesign(board.blockSize)
): PlatformLayout {
  const cellSize = { x: board.blockSize, y: board.blockSize, z: board.blockDepth };
  const footprintOuter = getFootprintRadius(board); // footprint outer ~= tower + bevel

  const ringAOuter = hallLayout.towerOuterRadius + design.marginBaseInner;
  const ringBOuter = footprintOuter + design.marginFootprint;
  const ringCOuter = hallLayout.platformOuterRadius;

  const ringA: PlatformRingLayout = {
    inner: 0,
    outer: ringAOuter,
    height: design.heights.ringA.height,
  };
  const ringB: PlatformRingLayout = {
    inner: ringA.outer,
    outer: ringBOuter,
    height: design.heights.ringB.height,
  };
  const ringC: PlatformRingLayout = {
    inner: ringB.outer,
    outer: ringCOuter,
    height: design.heights.ringC.height,
  };

  const cellBottomY = -cellSize.y * 0.5;
  const visibleLift = cellSize.y * 0.005; // lift platform top slightly above cube floor for visibility
  const baseY = cellBottomY + visibleLift - ringA.height;

  // Invariants / safety checks
  if (ringA.outer + EPS < ringB.inner || ringB.outer + EPS < ringC.inner) {
    console.warn('[platformLayout] ring ordering suspect', { ringA, ringB, ringC });
  }
  if (ringC.outer > hallLayout.platformOuterRadius + EPS) {
    console.warn('[platformLayout] ringC outer exceeds platform radius', {
      ringCOuter: ringC.outer,
      platformOuterRadius: hallLayout.platformOuterRadius,
    });
  }

  return {
    baseY,
    heightCore: design.heights.core,
    ringA,
    ringB,
    ringC,
  };
}
