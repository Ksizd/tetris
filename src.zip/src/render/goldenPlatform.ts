import * as THREE from 'three';
import { BoardDimensions } from '../core/types';
import { BoardRenderConfig } from './boardConfig';
import { HallLayoutRadii } from './hallLayout';
import { PlatformLayout, computePlatformLayout } from './platformLayout';
import { createDefaultPlatformDesign } from './platformDesign';
import { createGoldenPlatformGeometry } from './goldenPlatformGeometry';

export interface GoldenPlatformInstance {
  mesh: THREE.Mesh;
  layout: PlatformLayout;
  dispose: () => void;
}

export interface CreateGoldenPlatformParams {
  hallLayout: HallLayoutRadii;
  board: BoardRenderConfig;
  dimensions: BoardDimensions;
  designScale?: number;
}

const PLATFORM_ASSERT_EPS = 1e-4;

function assertPlatformInvariants(
  layout: PlatformLayout,
  board: BoardRenderConfig,
  hallLayout: HallLayoutRadii
): void {
  if (typeof console === 'undefined') {
    return;
  }
  const topA = layout.baseY + layout.ringA.height;
  const floor = -board.blockSize * 0.5;
  const gap = Math.abs(topA - floor);
  console.assert(
    gap <= 0.0105 + PLATFORM_ASSERT_EPS,
    '[goldenPlatform] ringA top must align with tower floor (<=1cm gap)',
    { topA, floor, gap }
  );
  console.assert(
    layout.ringC.outer <= hallLayout.platformOuterRadius + PLATFORM_ASSERT_EPS,
    '[goldenPlatform] ringC outer exceeds platformOuterRadius',
    { ringCOuter: layout.ringC.outer, platformOuterRadius: hallLayout.platformOuterRadius }
  );
  console.assert(
    Math.abs(layout.ringA.inner) <= PLATFORM_ASSERT_EPS,
    '[goldenPlatform] platform origin must stay at world center',
    { ringAInner: layout.ringA.inner }
  );
}

export function createGoldenPlatform(params: CreateGoldenPlatformParams): GoldenPlatformInstance {
  const design = createDefaultPlatformDesign(params.board.blockSize * (params.designScale ?? 1));
  const layout = computePlatformLayout(params.hallLayout, params.board, design);
  assertPlatformInvariants(layout, params.board, params.hallLayout);
  const geometry = createGoldenPlatformGeometry(layout, { segments: params.dimensions.width });

  const materials: THREE.Material[] = [
    new THREE.MeshStandardMaterial({ color: 0xd9b169, metalness: 0.55, roughness: 0.3 }),
    new THREE.MeshStandardMaterial({ color: 0xf1c779, metalness: 0.6, roughness: 0.26 }),
    new THREE.MeshStandardMaterial({ color: 0xf6d48e, metalness: 0.65, roughness: 0.32 }),
    new THREE.MeshStandardMaterial({ color: 0xe6c27a, metalness: 0.6, roughness: 0.36 }),
    new THREE.MeshStandardMaterial({ color: 0xc89f54, metalness: 0.58, roughness: 0.4 }),
  ];

  const mesh = new THREE.Mesh(geometry, materials);
  mesh.name = 'goldenPlatform';
  mesh.castShadow = true;
  mesh.receiveShadow = true;

  const dispose = () => {
    geometry.dispose();
    materials.forEach((m) => m.dispose());
  };

  return { mesh, layout, dispose };
}
