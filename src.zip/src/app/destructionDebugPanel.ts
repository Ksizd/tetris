export interface DestructionDebugPanel {
  dispose: () => void;
  getSelectedLevel: () => number | null;
  setLevels: (levels: number[]) => void;
  getFragmentFilter: () => FragmentDebugFilter;
  getLockFxVisible: () => boolean;
  onShowSourceRegion?: () => void;
  getPhysicsOverrides: () => PhysicsOverrides;
}

export type FragmentDebugFilter = 'all' | 'face' | 'gold' | 'dust' | 'fractureDebug';

export interface PhysicsOverrides {
  explosionStrength: number;
  gravityScale: number;
  dragScale: number;
}

export interface DestructionDebugOptions {
  levels: number[];
  onDestroy: (level: number) => void;
  onFilterChange?: (filter: FragmentDebugFilter) => void;
  onShowSourceRegion?: () => void;
  onLockFxVisibilityChange?: (visible: boolean) => void;
}

/**
 * Простая панель для visual debug: выбор уровня и кнопка Destroy level (реальную логику вызовет вызывающий код).
 */
export function createDestructionDebugPanel(options: DestructionDebugOptions): DestructionDebugPanel {
  let levels = [...options.levels];
  const container = document.createElement('div');
  Object.assign(container.style, {
    position: 'fixed',
    top: '12px',
    left: '12px',
    padding: '10px',
    background: 'rgba(15, 15, 18, 0.92)',
    color: '#e5e5e5',
    fontFamily: 'sans-serif',
    fontSize: '12px',
    borderRadius: '8px',
    zIndex: '2000',
    width: '220px',
    boxShadow: '0 4px 10px rgba(0,0,0,0.35)',
  });

  const title = document.createElement('div');
  title.textContent = 'Destruction (debug)';
  title.style.fontWeight = 'bold';
  title.style.marginBottom = '6px';
  container.appendChild(title);

  const selectLabel = document.createElement('label');
  selectLabel.textContent = 'Level to destroy';
  selectLabel.style.display = 'block';
  selectLabel.style.marginBottom = '4px';
  container.appendChild(selectLabel);

  const levelSelect = document.createElement('select');
  levelSelect.style.width = '100%';
  levelSelect.style.padding = '4px';
  levelSelect.style.marginBottom = '8px';

  function rebuildOptions() {
    const prev = levelSelect.value;
    levelSelect.innerHTML = '';
    levels.forEach((lvl) => {
      const opt = document.createElement('option');
      opt.value = lvl.toString();
      opt.textContent = lvl.toString();
      levelSelect.appendChild(opt);
    });
    if (levels.length > 0) {
      levelSelect.value = levels.includes(Number(prev)) ? prev : levels[0].toString();
    }
  }

  rebuildOptions();

  const destroyBtn = document.createElement('button');
  destroyBtn.textContent = 'Destroy level (real sim)';
  destroyBtn.style.width = '100%';
  destroyBtn.style.padding = '8px';
  destroyBtn.style.background = '#ff4d62';
  destroyBtn.style.color = '#fff';
  destroyBtn.style.border = 'none';
  destroyBtn.style.borderRadius = '6px';
  destroyBtn.style.cursor = 'pointer';
  destroyBtn.style.fontWeight = 'bold';
  destroyBtn.addEventListener('click', () => {
    const selected = Number.parseInt(levelSelect.value, 10);
    if (Number.isFinite(selected)) {
      options.onDestroy(selected);
    }
  });

  const filterLabel = document.createElement('label');
  filterLabel.textContent = 'Fragments debug';
  filterLabel.style.display = 'block';
  filterLabel.style.margin = '10px 0 4px';
  container.appendChild(filterLabel);

  const filterSelect = document.createElement('select');
  filterSelect.style.width = '100%';
  filterSelect.style.padding = '4px';
  ['all', 'face', 'gold', 'dust', 'fractureDebug'].forEach((key) => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = key;
    filterSelect.appendChild(opt);
  });
  filterSelect.value = 'all';
  filterSelect.addEventListener('change', () => {
    const value = filterSelect.value as FragmentDebugFilter;
    options.onFilterChange?.(value);
  });

  container.appendChild(levelSelect);
  container.appendChild(destroyBtn);
  container.appendChild(filterSelect);

  const sourceRegionBtn = document.createElement('button');
  sourceRegionBtn.textContent = 'Show source region (static)';
  sourceRegionBtn.style.width = '100%';
  sourceRegionBtn.style.padding = '6px';
  sourceRegionBtn.style.marginTop = '8px';
  sourceRegionBtn.style.background = '#4d82ff';
  sourceRegionBtn.style.color = '#fff';
  sourceRegionBtn.style.border = 'none';
  sourceRegionBtn.style.borderRadius = '6px';
  sourceRegionBtn.style.cursor = 'pointer';
  sourceRegionBtn.style.fontWeight = 'bold';
  sourceRegionBtn.addEventListener('click', () => {
    options.onShowSourceRegion?.();
  });
  container.appendChild(sourceRegionBtn);

  const lockFxLabel = document.createElement('label');
  lockFxLabel.style.display = 'flex';
  lockFxLabel.style.alignItems = 'center';
  lockFxLabel.style.gap = '6px';
  lockFxLabel.style.marginTop = '10px';
  const lockFxCheckbox = document.createElement('input');
  lockFxCheckbox.type = 'checkbox';
  lockFxCheckbox.checked = true;
  const lockFxText = document.createElement('span');
  lockFxText.textContent = 'Show lock FX bursts';
  lockFxLabel.appendChild(lockFxCheckbox);
  lockFxLabel.appendChild(lockFxText);
  lockFxCheckbox.addEventListener('change', () => {
    options.onLockFxVisibilityChange?.(lockFxCheckbox.checked);
  });
  container.appendChild(lockFxLabel);

  const tuning: PhysicsOverrides = {
    explosionStrength: 1,
    gravityScale: 1,
    dragScale: 1,
  };

  function addSlider(label: string, min: number, max: number, step: number, value: number, onChange: (v: number) => void) {
    const wrapper = document.createElement('div');
    wrapper.style.marginTop = '8px';
    const lbl = document.createElement('label');
    lbl.textContent = `${label}: ${value.toFixed(2)}`;
    lbl.style.display = 'block';
    lbl.style.marginBottom = '2px';
    const input = document.createElement('input');
    input.type = 'range';
    input.min = min.toString();
    input.max = max.toString();
    input.step = step.toString();
    input.value = value.toString();
    input.style.width = '100%';
    input.addEventListener('input', () => {
      const num = Number.parseFloat(input.value);
      if (!Number.isFinite(num)) return;
      onChange(num);
      lbl.textContent = `${label}: ${num.toFixed(2)}`;
    });
    wrapper.appendChild(lbl);
    wrapper.appendChild(input);
    container.appendChild(wrapper);
  }

  addSlider('Explosion strength', 0.1, 3, 0.05, tuning.explosionStrength, (v) => {
    tuning.explosionStrength = v;
  });
  addSlider('Gravity scale', 0.3, 2, 0.02, tuning.gravityScale, (v) => {
    tuning.gravityScale = v;
  });
  addSlider('Drag scale', 0, 3, 0.05, tuning.dragScale, (v) => {
    tuning.dragScale = v;
  });

  document.body.appendChild(container);

  return {
    dispose: () => container.remove(),
    getSelectedLevel: () => {
      const selected = Number.parseInt(levelSelect.value, 10);
      return Number.isFinite(selected) ? selected : null;
    },
    setLevels: (nextLevels: number[]) => {
      levels = [...nextLevels];
      rebuildOptions();
    },
    getFragmentFilter: () => filterSelect.value as FragmentDebugFilter,
    getLockFxVisible: () => lockFxCheckbox.checked,
    onShowSourceRegion: options.onShowSourceRegion,
    getPhysicsOverrides: () => ({ ...tuning }),
  };
}
